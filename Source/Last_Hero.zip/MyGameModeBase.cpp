// Fill out your copyright notice in the Description page of Project Settings.


#include "MyGameModeBase.h"
#include "MyCharacter.h"
#include "MyMonster.h"
#include "MyPlayerController.h"
#include <thread>
#include <map>
#include "Network.h"
extern HANDLE gmbEvent;
Network net;

// AMyMonster* monsters[10];
// AMyCharacter* players[10]; 4.6

AMyGameModeBase::AMyGameModeBase()
{
	PrimaryActorTick.bCanEverTick = true;
	DefaultPawnClass = AMyCharacter::StaticClass();
	PlayerControllerClass = AMyPlayerController::StaticClass();
	/*static ConstructorHelpers::FObjectFinder<UBlueprint> GOBLIN(TEXT("Blueprint'/Game/Game/BluePrints/Goblin/Monster_BP_2.Monster_BP_2'"));
	if (GOBLIN.Object) {
		MonsterBP = GOBLIN.Object;
	}*/
	static ConstructorHelpers::FObjectFinder<UBlueprint> GOBLIN_AI(TEXT("Blueprint'/Game/Game/BluePrints/Goblin/Ai_Monster_Goblin.Ai_Monster_Goblin'"));
	if (GOBLIN_AI.Object) {
		MonsterAIBP = GOBLIN_AI.Object;
	}
	//static ConstructorHelpers::FClassFinder<ACharacter> BP_CHARACTER_C(TEXT("/Game/Game/BluePrints/ThirdPersonCharacter.ThirdPersonCharacter_C"));

	/*if (BP_CHARACTER_C.Succeeded())
	{
		DefaultPawnClass = BP_CHARACTER_C.Class;
	}*/
	// gmbEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	// std::thread th{ GameThread };
	// th.join();
	// HANDLE gmbthread = CreateThread(NULL, 0, GameThread2, NULL, 0, NULL);

	// �α���â ���� ���� ������,��
	CS_LOGIN p;
	p.size = sizeof(CS_LOGIN);
	p.type = login_packet;
	strcpy_s(p.id, "test");
	strcpy_s(p.password, "1234");
	net.SendPacket(&p);
}

void AMyGameModeBase::PostLogin(APlayerController * NewPlayer)
{
	// �÷��̾� ���� ��ġ Ʈ������
	FTransform PlayerSpawnTrans(FRotator::ZeroRotator, FVector(14410.0f, 77670.0f, -450.0f), FVector(1.0f, 1.0f, 1.0f));
	// �÷��̾� ���� �ڵ�
	RestartPlayerAtTransform(NewPlayer, PlayerSpawnTrans);
	Super::PostLogin(NewPlayer);

	UE_LOG(LogTemp, Log, TEXT("NMHNMH1235466"));
}

void AMyGameModeBase::BeginPlay()
{
	// SpawnMonster();
}


void AMyGameModeBase::SpawnMonster()
{
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.bNoFail = true;
	SpawnInfo.Owner = this;
	SpawnInfo.Instigator = NULL;
	SpawnInfo.bDeferConstruction = false;
	// ���� ���� ��ġ(�ϴ� �Ѹ��� ��ġ�� �׽�Ʈ������)
	FVector MonSpawnLocation = { 19266.0f,78928.0f,-440.0f };
	// ���� ���� �ڵ�
	AMyMonster* SpawnMonster = GetWorld()->SpawnActor<AMyMonster>(MonToSpawn, MonSpawnLocation, FRotator::ZeroRotator, SpawnInfo); // �̷��� �ϸ� �������� �����س��� AI ������ �ȵȴ�
	/*AActor* SpawnMonster = GetWorld()->SpawnActor(MonsterBP->GeneratedClass);
	SpawnMonster->SetActorLocation(MonSpawnLocation);*/

}

void AMyGameModeBase::SpawnMonster(int oid, float x, float y, float z)
{
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.bNoFail = true;
	SpawnInfo.Owner = this;
	SpawnInfo.Instigator = NULL;
	SpawnInfo.bDeferConstruction = false;
	// ���� ���� ��ġ(�ϴ� �Ѹ��� ��ġ�� �׽�Ʈ������)
	FVector MonSpawnLocation = { x,y,z };
	// ���� ���� �ڵ�
	AMyMonster* SpawnMonster = GetWorld()->SpawnActor<AMyMonster>(MonToSpawn, MonSpawnLocation, FRotator::ZeroRotator, SpawnInfo); // �̷��� �ϸ� �������� �����س��� AI ������ �ȵȴ�
	SpawnMonster->SetObjectID(oid);
	// monsters.insert(oid, SpawnMonster);
	/*AActor* SpawnMonster = GetWorld()->SpawnActor(MonsterBP->GeneratedClass);
	SpawnMonster->SetActorLocation(MonSpawnLocation);*/

}

void AMyGameModeBase::SpawnPlayer(int oid, float x, float y, float z)
{
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.bNoFail = true;
	SpawnInfo.Owner = this;
	SpawnInfo.Instigator = NULL;
	SpawnInfo.bDeferConstruction = false;
	// ���� ���� ��ġ(�ϴ� �Ѹ��� ��ġ�� �׽�Ʈ������)
	FVector MonSpawnLocation = { x,y,z };
	// ���� ���� �ڵ�
	AMyCharacter* SpawnMonster = GetWorld()->SpawnActor<AMyCharacter>(MonToSpawn, MonSpawnLocation, FRotator::ZeroRotator, SpawnInfo); // �̷��� �ϸ� �������� �����س��� AI ������ �ȵȴ�
	// monsters.insert(oid, SpawnMonster);
	/*AActor* SpawnMonster = GetWorld()->SpawnActor(MonsterBP->GeneratedClass);
	SpawnMonster->SetActorLocation(MonSpawnLocation);*/

}

void AMyGameModeBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	auto& ev = net.gmb;
	UE_LOG(LogTemp, Log, TEXT("type :: %d"), (int)ev.type);
	if (net.gmb.type == sc_enter_obj) {
		if (net.gmb.oid < NPC_ID_START) {
			// Player Spawn
			// SpawnPlayer(net.gmb.oid, net.gmb.pos.x, net.gmb.pos.y, net.gmb.pos.z);
			// SpawnMonster(net.gmb.oid, net.gmb.pos.x, net.gmb.pos.y, net.gmb.pos.z);
			SpawnMonster();
			// FTransform spawnPos{ FVector(ev.pos.x, ev.pos.y, ev.pos.z) };
			// AController newPlayer;
			// RestartPlayerAtTransform(&newPlayer, spawnPos);
		}
		else if (net.gmb.oid < NPC_ID_START + MAX_MONSTER) {
			SpawnMonster(net.gmb.oid, net.gmb.pos.x, net.gmb.pos.y, net.gmb.pos.z);
			// SpawnPlayer(net.gmb.oid, net.gmb.pos.x, net.gmb.pos.y, net.gmb.pos.z);
			// APlayerController aa;
			// PostLogin(&aa);
			// auto& ev = net.gmb; 1.4
			// SpawnMonster(ev.oid, ev.pos.x, ev.pos.y, ev.pos.z);
			// FTransform spawnPos{ FVector(ev.pos.x, ev.pos.y, ev.pos.z) };
			// AController newPlayer;
			// RestartPlayerAtTransform(&newPlayer, spawnPos);
		}

		net.gmb.type = -1;
	}
	if (net.gmb.type == sc_update_obj) {
		UE_LOG(LogTemp, Log, TEXT("Character OID :: %d"), net.gmb.oid);

	}
	CS_MOVE p;
	p.destination = {};
	p.size = sizeof(p);
	p.type = move_packet;
	net.SendPacket(&p);
}
// 14900.0, 78160.0 -432.0
// DWORD WINAPI AMyGameModeBase::GameThread2(LPVOID arg) {
// 	// // AMyGameModeBase* my = reinterpret_cast<AMyGameModeBase*>(arg);
// 	// while (true) {
// 	// 	// WaitForSingleObject(gmbEvent, INFINITE);
// 	// }
// 	while (true)
// 		UE_LOG(LogTemp, Log, TEXT("Log Message"));
// }
// 
// void AMyGameModeBase::GameThread() {
// 	while (true)
// 		UE_LOG(LogTemp, Log, TEXT("Log Message"));
// }