// Fill out your copyright notice in the Description page of Project Settings.

#include "Last_Hero.h"
#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(Last_Hero);
IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Last_Hero, "LastHero" );
